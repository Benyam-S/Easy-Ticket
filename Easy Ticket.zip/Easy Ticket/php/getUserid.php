<?php
session_start();
$userid = $_SESSION['username'];
echo $userid;

?>